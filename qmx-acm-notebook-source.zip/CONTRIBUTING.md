# 参与开发

使用 Node.js 24 和 package.json 指定的 pnpm，安装依赖后运行 pnpm start。

提交 PR 前运行 pnpm check、pnpm test。更改界面后验证本地保存、标签筛选、收藏、复习状态、公开库同步；使用演示模式或测试仓库，不要向正式资料库提交测试记录。

目录分工：electron/ 为主进程、凭据和 GitHub API，ui/ 为无 Node 权限的页面，tests/ 为测试，tools/ 为打包，docs/ 为交接文档。

每个 PR 说明解决的问题、用户行为变化、验证结果和剩余限制。不要提交依赖、构建产物、私人错题、auth.json、个人 Token 或 OAuth Secret。Client ID 是公开应用标识，可配置，但修改队伍默认值应由维护者决定。

在线提交目前尚需真实账号验收；不要把本地模拟测试描述为线上登录或投稿通过。所有 GitHub 写入都须由用户明确点击提交触发。
