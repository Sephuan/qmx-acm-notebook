# 拾题 · QMX ACM Notebook

Windows 本地桌面错题与算法资料客户端，默认读取 https://github.com/qmx-acm-data/2026 。不需要购买服务器、数据库或域名。

![浅色界面示例](screenshots/preview-light.png)

## 项目交接

本仓库是客户端源码，资料来源保留在 [qmx-acm-data/2026](https://github.com/qmx-acm-data/2026)。推荐将客户端单独放在组织的 acm-notebook 仓库。上传、自动打包、发版和维护者交接步骤见 [GitHub 交接指南](docs/GITHUB_HANDOFF.md)，开发约定见 [贡献说明](CONTRIBUTING.md)。

当前为 0.1.0 预览版，尚未配置真实 OAuth 应用并完成在线写入验收。暂未选择开源许可证，源码公开不等于授予开源使用许可。

## 直接使用

解压便携包，双击「启动.cmd」或 QMX-Notebook.exe。若程序无法启动，使用「兼容启动.cmd」；当前机器的 Electron 原生沙箱启动失败，兼容启动禁用 Chromium 进程沙箱后已验证可运行，降低了进程隔离能力，页面仍保持 contextIsolation、关闭 nodeIntegration 并清洗 Markdown。请保留整个文件夹，不能只复制 exe。

- 公共题库：读取仓库 problems/、algorithms/ 的 Markdown 正式资料及 Issues 交流记录。
- 我的错题：独立查看本机私人记录以及本人提交的共享记录。
- 本地记录、草稿、收藏和复习状态保存在当前 Windows 用户的数据目录，不会自动公开。
- 只有点击「提交到公共题库」才上传。公共仓库的 Issue、评论和 PR 对所有人公开。
- 点击同步获取最新数据。不是逐字实时协作；其他设备同步后看到变化。
- 原生难度：CF rating 色阶、各平台 difficulty 文字；需要提交者填写或资料文件已有字段，当前不自动抓取平台 rating。
- 我的标签分布、数量与复习进度统计；Markdown、公式和代码展示；三种界面随时切换。

初始仓库目前没有正式题解或错题，真实客户端显示空库是正常现象。直接打开 ui/index.html 为带明确示例标记的界面演示，不是实际客户端。

## 首次启用在线投稿（负责人只需配置一次应用）

1. 在 GitHub Settings → Developer settings → OAuth Apps → New OAuth App 注册免费的 OAuth 应用。应用名可填写 QMX Notebook；Homepage 可用仓库地址；Callback URL 可填 http://localhost（本程序使用设备授权，不启动回调服务）。
2. 打开应用设置，启用 Device Flow。
3. 复制 Client ID，在客户端右上角设置中填写。不需要 Client Secret，切勿把 Secret 或个人 Token 发给队员。
4. 队员使用相同 Client ID，点击左下角登录按钮。浏览器会打开 github.com/login/device，在网页中输入客户端显示的验证码并确认。
5. 登录后可以创建错题 Issue、发表评论，或将正式题解提交到本人 Fork 再向原仓库发起 PR。

OAuth 请求 public_repo 权限，涉及该用户有权限操作的公开仓库，不能限定为这一个仓库。组织若限制第三方 OAuth 应用，需要组织负责人批准。未配置 Client ID 时，本地记录和公开资料读取仍可用。

公开提交依赖网络和实际 GitHub 权限。首版已实现设备授权、Issue、评论和 Fork PR 调用，但未使用真实队员账号完成外部写入验收；发布给全队前应先用测试账号提交一条测试 Issue 与 PR。首次 Fork 可能尚未准备好，界面会提示稍后重试。写请求超时不要连续重试，先查看 GitHub 是否已经成功，避免重复投稿。已有记录的公共正文编辑、PR 后续跟进编辑、附件上传、自动去重及多设备私人记录同步暂未实现。

## 数据和安全

Electron 主进程进行 GitHub 网络请求，渲染页面不接触令牌。令牌通过 Electron safeStorage 使用 Windows 用户凭据加密保存；退出登录会删除本机凭据。若需撤销远端授权，请前往 https://github.com/settings/applications 。

本地数据路径通常是 %APPDATA%\qmx-acm-notebook。local.json 为个人内容，cache.json 为公共数据缓存，auth.json 为加密登录信息。不要分享整个用户数据目录。设置中可导出本地 JSON 备份；首版尚未提供界面导入，可通过维护者恢复 local.json。

Markdown 经 DOMPurify 清洗，禁止页面网络连接和远端图片。外部链接经主进程校验，只允许 GitHub 和当前支持的题目平台 HTTPS 地址。客户端不包含管理员凭据。

匿名 API 常见额度为每 IP 每小时 60 次，登录后通常为每用户每小时 5000 次，受 GitHub 当前政策和其他应用共享用量影响。客户端按文件 SHA 缓存正文并分页读取，避免频繁点击同步；免费平台政策不由本项目保证。

## 开发

安装 Node.js 24，在项目目录用 Corepack 启用 package.json 指定的 pnpm（或自行安装对应版本），然后执行：

```powershell
corepack enable
pnpm install --frozen-lockfile
pnpm start
pnpm check
pnpm test
pnpm package
```

packager 使用独立暂存目录收集运行依赖，输出 release/QMX-Notebook-win32-x64。未购买代码签名证书，系统可能显示未知发布者提示。

如果在本机遇到图形驱动相关启动失败，启动脚本提供 --disable-gpu。自动化桌面检查在当前受管理环境下额外使用 --no-sandbox，仅为测试启动参数，不作为默认发行配置。

## 正式 Markdown 字段

兼容原仓库 YAML front matter：pid、title、platform、tags、author、date，新增可选 rating 和 difficulty。

```yaml
---
pid: CF1A
title: Theatre Square
platform: CF
rating: 1000
difficulty: ''
tags: [数学, 实现]
author: github-login
date: 2026-11-01
---
```

快速错题 Issue 正文包含 qmx-record JSON 隐藏标记保存题号、平台、标签及难度，不依赖普通队员设置 GitHub Labels 的权限。
